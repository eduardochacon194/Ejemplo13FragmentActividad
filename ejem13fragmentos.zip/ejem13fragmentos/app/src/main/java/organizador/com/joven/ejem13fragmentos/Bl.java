package organizador.com.joven.ejem13fragmentos;


import android.content.Intent;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class Bl extends Fragment {

    private TextView no,pa,co;
    private Button button;

    public Bl() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_bl, container, false);
        pa=(TextView)rootview.findViewById(R.id.msg1);
        no=(TextView)rootview.findViewById(R.id.msg2);
        co=(TextView)rootview.findViewById(R.id.msg3);

        Bundle bundle=getArguments();
        no.setText(String.valueOf(bundle.getString("msg1")));
        pa.setText(String.valueOf(bundle.getString("msg2")));
        co.setText(String.valueOf(bundle.getString("msg3")));
        button = (Button) rootview.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData();
            }
        });
        return rootview;
    }
    private void sendData()
    {
        //INTENT OBJ
        Intent i = new Intent(getActivity().getBaseContext(),Activity2.class);

        //PACK DATA
        i.putExtra("msg1", no.getText().toString());
        i.putExtra("msg2", pa.getText().toString());
        i.putExtra("msg3", co.getText().toString());

        //START ACTIVITY
        getActivity().startActivity(i);
    }


}
