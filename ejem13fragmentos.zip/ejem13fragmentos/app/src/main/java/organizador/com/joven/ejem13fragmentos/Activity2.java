package organizador.com.joven.ejem13fragmentos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {

    private TextView t1,t2,t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        t2= (TextView) findViewById(R.id.txt1);
        t1= (TextView) findViewById(R.id.txt2);
        t3= (TextView) findViewById(R.id.txt3);

        Intent i = getIntent();
        t1.setText(i.getStringExtra("msg1"));
        t2.setText(i.getStringExtra("msg2"));
        t3.setText(i.getStringExtra("msg3"));
    }
}
